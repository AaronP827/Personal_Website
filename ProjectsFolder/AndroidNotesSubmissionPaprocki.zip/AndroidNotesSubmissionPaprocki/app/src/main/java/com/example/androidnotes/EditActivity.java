package com.example.androidnotes;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class EditActivity extends AppCompatActivity
{
    //Fields for edit activity
    private final String TAG = getClass().getSimpleName();
    private EditText noteTitle;
    private EditText noteBody;
    private final Note editNote = new Note();
    private Editable originalTitle;
    private Editable originalBody;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_activity);

        noteTitle = findViewById(R.id.editTitle);
        noteBody = findViewById(R.id.editBody);
        noteBody.setMovementMethod(new ScrollingMovementMethod());

        //Checks to see if the main activity passed an intent
        Intent fromMain = getIntent();
        if(fromMain.hasExtra("TITLE") && fromMain.hasExtra("BODY"))
        {
            //Storing values from main activity note into edit note
            editNote.setTitle(fromMain.getExtras().getString("TITLE"));
            editNote.setBody(fromMain.getExtras().getString("BODY"));

            if(editNote != null)
            {
                //Populating fields with note passed from main activity
                String editTitle = editNote.getTitle();
                noteTitle.setText(editTitle);
                String editBody = editNote.getBody();
                noteBody.setText(editBody);
                originalTitle = noteTitle.getText();
                originalBody = noteBody.getText();
            }
            else
            {
                //If no note was passed from main activity set the text views to empty
                noteTitle.setText("");
                noteBody.setText("");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.edit_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        //User clicked on the save note button
        if(item.getItemId() == R.id.saveEditsButton)
        {
            saveNote();
        }
        else
        {
            Log.d(TAG, "onOptionsItemSelected: An unknown option has been selected");
        }
        return super.onOptionsItemSelected(item);
    }

    public void saveNote(){
        //Checks to see if there is text in the fields before it will try to save
        String titleStr = noteTitle.getText().toString();
        String bodyStr = noteBody.getText().toString();
        if(titleStr.isEmpty())
        {
            //If the title or body is empty it will not allow the user to save the note
            noTitleDialog();
            return;
        }
        //Saves the info put into the edit texts into editNote and adds it to an intent to send back to the main activity
        editNote.setTitle(titleStr);
        editNote.setBody(bodyStr);
        Log.d(TAG, "onOptionsItemSelected: Save Button Selected and saving a new note with title " + titleStr + " and body " + bodyStr);
        Intent noteInfo = new Intent(this, MainActivity.class);
        noteInfo.putExtra("NOTE", editNote);
        Toast.makeText(this, "Note successfully saved", Toast.LENGTH_SHORT).show();
        setResult(RESULT_OK, noteInfo);
        finish();
    }
    public void noTitleDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("OK", (dialog, id) -> {
            Intent noTitle = new Intent(this, MainActivity.class);
            setResult(RESULT_OK);
            finish();
        });
        builder.setNegativeButton("CANCEL", (dialog, id) -> Toast.makeText(this, "Continue", Toast.LENGTH_SHORT).show());
        builder.setTitle("Your note has no title");
        builder.setMessage("Your note needs a title.\n\nWould you like to exit without saving the note?");
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    @Override
    public void onBackPressed() {
        //Set up a dialog box to see if the user wants to save the note when they hit the back button
        //Checks to see if the user changed the original text when editing a note
        if(noteTitle.getText().equals(originalTitle) && noteBody.getText().equals(originalBody))
        {
            saveNote();
            return;
        }
        else
        {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setPositiveButton("YES", (dialog, id) -> saveNote());
            builder.setNegativeButton("NO", (dialog, id) -> {
                Intent noSave = new Intent(this, MainActivity.class);
                startActivity(noSave);
                super.onBackPressed();

            });
            builder.setTitle("Your note is not saved.");
            builder.setMessage("Would you like to save your note?\n\nIf you do not save your note it will be deleted.");
            AlertDialog dialog = builder.create();
            dialog.show();
        }
    }
}
