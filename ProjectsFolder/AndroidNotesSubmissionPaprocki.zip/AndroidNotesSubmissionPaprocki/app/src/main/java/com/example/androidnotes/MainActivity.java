package com.example.androidnotes;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener{

    //Fields for the main activity
    private final String TAG = getClass().getSimpleName();
    private RecyclerView recyclerView;
    private static NoteThumbnailAdapter noteThumbnailAdapter;
    private static final ArrayList<Note> noteList = new ArrayList<>();
    private static LinearLayoutManager linearLayoutManager;
    private ActivityResultLauncher<Intent> activityResultLauncher;

    @SuppressLint("NotifyDataSetChanged")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Initializes the recycler view
        recyclerView = findViewById(R.id.thumbNailRecycler);
        noteThumbnailAdapter = new NoteThumbnailAdapter(this, noteList);
        recyclerView.setAdapter(noteThumbnailAdapter);
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        noteList.clear();
        noteList.addAll(loadFile());
        noteThumbnailAdapter.notifyDataSetChanged();

        //Sets up result handler to receive the note back from the edit/create method
        activityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), this::handler);
        getSupportActionBar().setTitle("Android Notes(" + noteList.size() + ")");
    }

    @Override
    protected void onResume() {
        getSupportActionBar().setTitle("Android Notes(" + noteList.size() + ")");
        super.onResume();
    }

    //Handler method to take the notes passed from the edit/ create note activity
    private void handler(ActivityResult result){
        //Makes sure there is in fact a note being passed
        if(result == null || result.getData() == null)
        {
            Log.d(TAG, "handler: NULL intent received");
        }
        //Creating an intent to match the intent being passed
        if(result.getData() != null){


            Intent i = result.getData();
            if(result.getResultCode() == RESULT_OK)
            {
                //Creating a new note with the information passed from the edit/ create activity
                Note newNote = (Note) i.getSerializableExtra("NOTE");
                if(newNote != null)
                {
                    //Updating the visuals with the new note
                    //getSupportActionBar().setTitle("Android Notes(" + noteList.size() + ")");
                    noteList.add(0, newNote);
                    noteThumbnailAdapter.notifyItemInserted(0);
                    linearLayoutManager.scrollToPosition(0);
                }
                else {
                    Log.d(TAG, "handler: null note passed");
                }
            }
        }
        else
        {
            return;
        }
    }

    private ArrayList<Note> loadFile() {
        ArrayList<Note> tempNoteList = new ArrayList<>();
        try {
            InputStream is = getApplicationContext().openFileInput(getString(R.string.file_name));
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            JSONArray jsonArray = new JSONArray(sb.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String title = jsonObject.getString("title");
                String body = jsonObject.getString("body");
                Note note = new Note(title, body);
                tempNoteList.add(note);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tempNoteList;
    }

    @Override
    protected void onPause() {
        saveProduct();
        super.onPause();
    }

    private void saveProduct()
    {
        try{
            FileOutputStream fos = getApplicationContext().
                    openFileOutput(getString(R.string.file_name), Context.MODE_PRIVATE);

            PrintWriter printWriter = new PrintWriter(fos);
            printWriter.print(noteList);
            printWriter.close();
            fos.close();

            Log.d(TAG, "saveProduct: JSON:\n" + noteList.toString());
        }catch (Exception e){
            e.getStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        //User selects the create new note button
        if(item.getItemId() == R.id.addNewNoteButton)
        {
            Log.d(TAG, "onOptionsItemSelected: Add new note menu button has been selected");
            Intent newNote = new Intent(this, EditActivity.class);
            setResult(RESULT_OK);
            activityResultLauncher.launch(newNote);
        }
        //User selects the about button
        else if(item.getItemId() == R.id.infoButton)
        {
            Log.d(TAG, "onOptionsItemSelected: Info menu button has been selected");
            setContentView(R.layout.about_activity);
            Intent about = new Intent(this, AboutActivity.class);
            startActivity(about);
        }
        else
        {
            Log.d(TAG, "onOptionsItemSelected: Unknown menu option has been selected");
        }
        return super.onOptionsItemSelected(item);
    }

    //User does a short click on a note to edit it
    @Override
    public void onClick(View view) {
        int pos = recyclerView.getChildLayoutPosition(view);
        Note n = noteList.get(pos);
        Intent editNote = new Intent(this, EditActivity.class);
        editNote.putExtra("TITLE", n.getTitle());
        editNote.putExtra("BODY", n.getBody());
        deleteNote(pos);
        activityResultLauncher.launch(editNote);
    }

    //User long clicks on a note to delete it
    @Override
    public boolean onLongClick(View view) {
        int pos = recyclerView.getChildLayoutPosition(view);
        deleteDialog(pos);
        return true;
    }
    //
    private void deleteNote(int index)
    {
        if (!noteList.isEmpty()) {
            Toast.makeText(this, noteList.get(index).getTitle() + " has been successfully deleted", Toast.LENGTH_LONG).show();
            noteList.remove(index);
            noteThumbnailAdapter.notifyItemRemoved(index);
            linearLayoutManager.scrollToPosition(index);
            getSupportActionBar().setTitle("Android Notes(" + noteList.size() + ")");
        }
    }
    private void deleteDialog(int index)
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setPositiveButton("YES", (dialog, id) -> deleteNote(index));
        builder.setNegativeButton("NO", (dialog, id) -> Toast.makeText(this, "Note not deleted", Toast.LENGTH_SHORT).show());
        builder.setTitle("Delete " + noteList.get(index).getTitle() + "?");
        builder.setMessage("Would you like to delete the note named " + noteList.get(index).getTitle() + "?");
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}