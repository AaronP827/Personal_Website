package com.example.androidnotes;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NoteThumbnailAdapter extends RecyclerView.Adapter<NoteThumbnailViewHolder>{

    //Creates the adapter for the recycler
    private ArrayList<Note> noteThumbnailList = new ArrayList<Note>();
    private final MainActivity mainAct;
    public NoteThumbnailAdapter(MainActivity mainAct, ArrayList<Note> noteThumbnailList)
    {
        this.mainAct = mainAct;
        this.noteThumbnailList = noteThumbnailList;
    }

    @NonNull
    @Override
    public NoteThumbnailViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.note_thumbnail, parent, false);
        itemView.setOnClickListener(mainAct);
        itemView.setOnLongClickListener(mainAct);
        return new NoteThumbnailViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteThumbnailViewHolder holder, int position) {
        Note n = noteThumbnailList.get(position);
        if(n.getTitle().length() > 80)
        {
            holder.noteTitleT.setText(n.getTitle().substring(0,81) + "...");
        }
        else
        {
            holder.noteTitleT.setText(n.getTitle());
        }
        if(n.getBody().length() > 80)
        {
            holder.previewT.setText(n.getBody().substring(0,81) + "...");
        }
        else
        {
            holder.previewT.setText(n.getBody());
        }
        holder.lastEditT.setText(n.getLastEditDate());
    }

    @Override
    public int getItemCount() {
        return noteThumbnailList.size();
    }
}
