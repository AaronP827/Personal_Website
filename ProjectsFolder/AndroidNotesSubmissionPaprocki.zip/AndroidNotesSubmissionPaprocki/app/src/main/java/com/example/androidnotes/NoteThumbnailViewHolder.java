package com.example.androidnotes;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class NoteThumbnailViewHolder extends RecyclerView.ViewHolder
{
    TextView noteTitleT;
    TextView lastEditT;
    TextView previewT;

    public NoteThumbnailViewHolder(@NonNull View itemView) {
        super(itemView);
        noteTitleT = itemView.findViewById(R.id.thumbnailTitle);
        lastEditT = itemView.findViewById(R.id.lastUpdateThumb);
        previewT = itemView.findViewById(R.id.thumbBody);
    }
}
