package com.example.androidnotes;

import android.util.JsonWriter;

import androidx.annotation.NonNull;

import java.io.IOException;
import java.io.Serializable;
import java.io.StringWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Note implements Serializable
{
    //Fields for note class
    private String title;
    private Date lastEditDate;
    private String body;
    private final DateFormat dateFormat = new SimpleDateFormat("E, MMM dd hh:mm aa");
    private String strDate;
    private static int counter = 1;

    //Default constructor
    public Note() {
        this.title = "Title" + counter;
        this.lastEditDate = Calendar.getInstance().getTime();
        this.body = "Body";
        counter++;
    }
    //Constructor that accepts a title and body to build a new note
    Note(String t, String b)
    {
        this.title = t;
        this.body = b;
        this.lastEditDate = Calendar.getInstance().getTime();
        counter++;
    }

    //Getter and Setters
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getLastEditDate() {
        strDate = dateFormat.format(lastEditDate);
        return strDate;
    }
    public void setLastEditDate() {
        lastEditDate = Calendar.getInstance().getTime();
    }
    public String getBody() {
        return body;
    }
    public void setBody(String body) {
        this.body = body;
    }

    //To String for the .json reader
    @NonNull
    public String toString() {

        try {
            StringWriter sw = new StringWriter();
            JsonWriter jsonWriter = new JsonWriter(sw);
            jsonWriter.setIndent("  ");
            jsonWriter.beginObject();
            jsonWriter.name("title").value(getTitle());
            jsonWriter.name("body").value(getBody());
            jsonWriter.endObject();
            jsonWriter.close();
            return sw.toString();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "";
    }
}
