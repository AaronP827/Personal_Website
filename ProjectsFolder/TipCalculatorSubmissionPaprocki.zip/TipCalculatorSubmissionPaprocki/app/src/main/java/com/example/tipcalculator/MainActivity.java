package com.example.tipcalculator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.MediaDrm;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    //Global variables declared to be used throughout the project
    private final String TAG = getClass().getSimpleName();

    //Text fields declared
    private EditText totalBeforeTip;
    private EditText numOfPeople;
    private TextView totalAfterTip;
    private TextView tipAmount;
    private TextView totalPerPerson;
    private TextView overdraft;
    private RadioGroup tipAmountGroup;

    //Global variables used in calculation for total after tip and the final bill per person
    private double tat;
    private double tppNum;
    private double overage;
    private DecimalFormat df = new DecimalFormat("0.00");

    //onCreate Method
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Linking variables to the buttons
        totalBeforeTip = findViewById(R.id.billTotalField);
        numOfPeople = findViewById(R.id.numberOfPeopleField);
        totalAfterTip = findViewById(R.id.totalOutput);
        tipAmount = findViewById(R.id.tipAmountOutput);
        totalPerPerson = findViewById(R.id.totalPerPersonOutput);
        overdraft = findViewById(R.id.overageOutput);
        tipAmountGroup = findViewById(R.id.tipRadioGroup);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState)
    {
        //Saving global variables if the program is killed for maintaining the app when switched to landscape
        outState.putString("NUMBER OF PEOPLE", (numOfPeople).getText().toString());
        outState.putString("TOTAL BEFORE TIP", (totalBeforeTip).getText().toString());
        outState.putString("TIP AMOUNT", (tipAmount).getText().toString());
        outState.putString("TOTAL AFTER TIP", (totalAfterTip).getText().toString());
        outState.putString("TOTAL PER PERSON", (totalPerPerson).getText().toString());
        outState.putString("OVERDRAFT", (overdraft).getText().toString());
        outState.putDouble("TAT", tat);
        outState.putDouble("TPPNUM", tppNum);
        outState.putDouble("OVERAGE", overage);

        super.onSaveInstanceState(outState);
    }
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState)
    {
        //Restores global variables if switching orientations
        super.onRestoreInstanceState(savedInstanceState);

        totalBeforeTip.setText(savedInstanceState.getString("TOTAL BEFORE TIP"));
        tipAmount.setText(savedInstanceState.getString("TIP AMOUNT"));
        tat = savedInstanceState.getDouble("TAT");
        totalAfterTip.setText(savedInstanceState.getString("TOTAL AFTER TIP"));
        numOfPeople.setText(savedInstanceState.getString("NUMBER OF PEOPLE"));
        tppNum = savedInstanceState.getDouble("TPPNUM");
        totalPerPerson.setText(savedInstanceState.getString("TOTAL PER PERSON"));
        overage = savedInstanceState.getDouble("OVERAGE");
        overdraft.setText(savedInstanceState.getString("OVERDRAFT"));

    }

    @SuppressLint("SetTextI18n")
    public void computeBill(View view) {
        String nop = numOfPeople.getText().toString();
        //checks to see if the number of people field is empty
        if(nop.trim().isEmpty())
        {
            //returns if there is no user input for number of people
            return;
        }
        Log.d(TAG, "computeBill: Computing bill for " + nop + " people");

        int nopNum = Integer.parseInt(nop);
        //check to see if the bill split can be calculated evenly
        if(tat % nopNum == 0)
        {
            //splits the bill evenly amongst the number of people
            tppNum = (tat / nopNum);
            String tppString = df.format(tppNum);
            totalPerPerson.setText("$" + tppString);
            overdraft.setText("$0.00");
        }
        else
        {
            //splits the bill with overage if it cannot be split evenly amongst the number of people selected
            tppNum = (tat/nopNum) + .005;
            overage = (tppNum * nopNum) - tat;
            String tppString = df.format(tppNum);
            tppNum = Double.parseDouble(tppString);
            overage = (tppNum * nopNum) - tat;
            String overageString = df.format(overage);
            totalPerPerson.setText("$" + tppString);
            overdraft.setText("$" + overageString);
        }
    }

    //Clears all of the text fields
    public void clearBoard(View view) {
        Log.d(TAG, "clearBoard: Resetting the app to a blank slate");
        tipAmountGroup.clearCheck();
        totalBeforeTip.setText("");
        numOfPeople.setText("");
        totalPerPerson.setText("");
        overdraft.setText("");
        tipAmount.setText("");
        totalAfterTip.setText("");
    }


    @SuppressLint("SetTextI18n")
    public void tipGroup(View view)
    {
        Log.d(TAG, "tipGroup: Selecting the tip percentage and calculating total");
        //makes sure that a bill is inserted before a tip amount can be selected
        String tbt = totalBeforeTip.getText().toString();
        if(tbt.trim().isEmpty())
        {
            //unchecks the button if no bill is given
            tipAmountGroup.clearCheck();
            return;
        }
        double tbtNum = Double.parseDouble(tbt);
        //Checks to see if 12% is selected and computes bill if so
        if(view.getId() == R.id.twelvePercentButton)
        {
            double tip = tbtNum *.12;
            tat = tbtNum + tip;
            String tatString = df.format(tat);
            String tipString = df.format(tip);
            tipAmount.setText("$" + tipString);
            totalAfterTip.setText("$" + tatString);
        }
        //Checks to see if 15% tip is selected and computes if so
        else if(view.getId() == R.id.fifteenPercentButton)
        {
            double tip = tbtNum *.15;
            tat = tbtNum + tip;
            String tatString = df.format(tat);
            String tipString = df.format(tip);
            tipAmount.setText("$" + tipString);
            totalAfterTip.setText("$" + tatString);
        }
        //Checks to see if 18% is selected and computes bill if so
        else if(view.getId() == R.id.eighteenPercentButton)
        {
            double tip = tbtNum *.18;
            tat = tbtNum + tip;
            String tatString = df.format(tat);
            String tipString = df.format(tip);
            tipAmount.setText("$" + tipString);
            totalAfterTip.setText("$" + tatString);
        }
        //Checks to see if 20% is selected and computes the bill if so
        else if(view.getId() == R.id.twentyPercentButton)
        {
            double tip = tbtNum *.20;
            tat = tbtNum + tip;
            String tatString = df.format(tat);
            String tipString = df.format(tip);
            tipAmount.setText("$" + tipString);
            totalAfterTip.setText("$" + tatString);
        }
    }
}