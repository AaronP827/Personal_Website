package com.example.weatherforecast;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DailyViewHolder extends RecyclerView.ViewHolder {
    TextView date;
    TextView highLow;
    TextView description;
    TextView percip;
    TextView uv;
    TextView morningTemp;
    TextView afternoonTemp;
    TextView eveningTemp;
    TextView nightTemp;
    ImageView image;

    public DailyViewHolder(@NonNull View itemView) {
        super(itemView);
        date = itemView.findViewById(R.id.dateVertThumb);
        highLow = itemView.findViewById(R.id.dailyHighLow);
        description = itemView.findViewById(R.id.dailyVertDescription);
        percip = itemView.findViewById(R.id.dailyVertPercipitation);
        uv = itemView.findViewById(R.id.dailyVertUV);
        morningTemp = itemView.findViewById(R.id.dailyVertMorning);
        afternoonTemp = itemView.findViewById(R.id.dailyVertAfternoon);
        eveningTemp = itemView.findViewById(R.id.dailyVertEvening);
        nightTemp = itemView.findViewById(R.id.dailyVertNight);
        image = itemView.findViewById(R.id.dailyVertImage);
    }
}
