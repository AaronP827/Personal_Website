package com.example.weatherforecast;

import android.net.Uri;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

public class ContentDownloader
{
    //Fields for the main content downloader

    private static MainActivity mainActivity;
    private static RequestQueue queue;
    private static Weather weatherObj;

    private static final ArrayList<HourlyWeather> hourlyList = new ArrayList<>();

    private static final String myAPIKey = "de9b3d8ad25a928933d3113841cdb5c8";
    private static String weatherURL = "https://api.openweathermap.org/data/2.5/onecall";

    public static void downloadInfo(MainActivity mainActivityIn, double lat, double lon, boolean units)
    {
        hourlyList.clear();
        mainActivity = mainActivityIn;
        queue = Volley.newRequestQueue(mainActivity);

        //Creates the URL to make the API call
        Uri.Builder buildURL = Uri.parse(weatherURL).buildUpon();
        buildURL.appendQueryParameter("lat", Double.toString(lat));
        buildURL.appendQueryParameter("lon", Double.toString(lon));
        buildURL.appendQueryParameter("appid", myAPIKey);
        buildURL.appendQueryParameter("units", (units ? "imperial" : "metric"));
        buildURL.appendQueryParameter("exclude", "minutely");
        String urlToUse = buildURL.build().toString();
        Response.Listener<JSONObject> listener = response -> parseInfo(response.toString());

        Response.ErrorListener error = error1 -> {
            try {
                mainActivity.updateData(null);
            } catch (IOException e) {
                e.printStackTrace();
            }
        };

        // Request a string response from the provided URL.
        JsonObjectRequest jsonObjectRequest =
                new JsonObjectRequest(Request.Method.GET, urlToUse, null, listener, error);

        // Add the request to the RequestQueue.
        queue.add(jsonObjectRequest);
    }
    //Parses the information from the result of the API call
    public static void parseInfo(String s)
    {
        try {
            JSONObject jObjMain = new JSONObject(s);
            String timezoneOffset = jObjMain.getString("timezone_offset");

            //Main weather section
            JSONObject current = jObjMain.getJSONObject("current");
            String dt = current.getString("dt");
            String sunrise = current.getString("sunrise");
            String sunset = current.getString("sunset");
            String temp = current.getString("temp");
            String feelsLike = current.getString("feels_like");
            String humidity = current.getString("humidity");
            String uvi = current.getString("uvi");
            String clouds = current.getString("clouds");
            String visibility = current.getString("visibility");
            String windSpeed = current.getString("wind_speed");
            String windDeg = current.getString("wind_deg");

            //Current weather section with description
            JSONArray currentWeatherArray = current.getJSONArray("weather");
            JSONObject currentWeather = (JSONObject) currentWeatherArray.get(0);
            String description = currentWeather.getString("description");
            String icon = currentWeather.getString("icon");

            //Daily data for main activity
            JSONArray dailyWeatherArray = jObjMain.getJSONArray("daily");
            JSONObject dailyMain = (JSONObject) dailyWeatherArray.get(0);
            JSONObject dailyTemps = dailyMain.getJSONObject("temp");
            String dailyMorning = dailyTemps.getString("morn");
            String dailyAfternoon = dailyTemps.getString("day");
            String dailyEvening = dailyTemps.getString("eve");
            String dailyNight = dailyTemps.getString("night");

            JSONArray hourly = jObjMain.getJSONArray("hourly");
            for(int i = 0; i < hourly.length(); i ++)
            {
                JSONObject tempHourly = (JSONObject) hourly.get(i);
                JSONArray tempHourlyWeather = tempHourly.getJSONArray("weather");
                JSONObject tempHourlyInstance = (JSONObject) tempHourlyWeather.get(0);
                String hourlyDt = tempHourly.getString("dt");
                String hourlyTemp = tempHourly.getString("temp");
                String hourlyDescription = tempHourlyInstance.getString("description");
                String hourlyIcon = tempHourlyInstance.getString("icon");
                hourlyList.add(new HourlyWeather(hourlyDt, hourlyTemp, hourlyDescription, hourlyIcon, timezoneOffset));
            }

            //Conversion to String for wind information
            double windsDub = Double.parseDouble(windSpeed);
            int windsInt = Math.toIntExact(Math.round(windsDub));

            String windFinal = getDirection(Double.parseDouble(windDeg)) + " at " + windsInt;
            String descriptionFinal = description + " (" + clouds + "% clouds)";

            weatherObj = new Weather(sunset, sunrise, temp, feelsLike, humidity, uvi,
                    visibility, windFinal, descriptionFinal, dailyMorning, dailyAfternoon,
                    dailyEvening, dailyNight, timezoneOffset, dt, icon);

            mainActivity.updateData(weatherObj);
            mainActivity.updateHourly(hourlyList);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //Takes the data from the API call and sees what direction the wind is going
    private static String getDirection(double degrees) {
        if (degrees >= 337.5 || degrees < 22.5)
            return "N";
        if (degrees >= 22.5 && degrees < 67.5)
            return "NE";
        if (degrees >= 67.5 && degrees < 112.5)
            return "E";
        if (degrees >= 112.5 && degrees < 157.5)
            return "SE";
        if (degrees >= 157.5 && degrees < 202.5)
            return "S";
        if (degrees >= 202.5 && degrees < 247.5)
            return "SW";
        if (degrees >= 247.5 && degrees < 292.5)
            return "W";
        if (degrees >= 292.5 && degrees < 337.5)
            return "NW";
        return "X";
    }
}
