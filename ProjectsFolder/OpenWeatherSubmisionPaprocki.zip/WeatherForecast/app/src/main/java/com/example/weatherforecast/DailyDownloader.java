package com.example.weatherforecast;


import android.net.Uri;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

public class DailyDownloader {
    //Fields for the downloader
    private static DailyVertActivity dailyAct;
    private static final ArrayList<DailyWeather> dailyList = new ArrayList<>();
    private static RequestQueue queue;

    private static final String myAPIKey = "de9b3d8ad25a928933d3113841cdb5c8";
    private static String weatherURL = "https://api.openweathermap.org/data/2.5/onecall";

    public static void downloadInfo(DailyVertActivity dailyActivityIn, double lat, double lon, boolean units)
    {
        dailyList.clear();
        dailyAct = dailyActivityIn;
        queue = Volley.newRequestQueue(dailyAct);

        //Builds a url to make a call to the API
        Uri.Builder buildURL = Uri.parse(weatherURL).buildUpon();
        buildURL.appendQueryParameter("lat", Double.toString(lat));
        buildURL.appendQueryParameter("lon", Double.toString(lon));
        buildURL.appendQueryParameter("appid", myAPIKey);
        buildURL.appendQueryParameter("units", (units ? "imperial" : "metric"));
        buildURL.appendQueryParameter("exclude", "minutely");
        String urlToUse = buildURL.build().toString();
        Response.Listener<JSONObject> listener = response -> parseInfo(response.toString());

        Response.ErrorListener error = error1 -> dailyAct.updateData(null);

        // Request a string response from the provided URL.
        JsonObjectRequest jsonObjectRequest =
                new JsonObjectRequest(Request.Method.GET, urlToUse, null, listener, error);

        // Add the request to the RequestQueue.
        queue.add(jsonObjectRequest);
    }
    //Parses the resulting information from the API
    public static void parseInfo(String s)
    {
        try {
            JSONObject jObjMain = new JSONObject(s);
            String timezoneOffset = jObjMain.getString("timezone_offset");

            JSONArray dailyWeatherArray = jObjMain.getJSONArray("daily");
            for(int i = 0; i < dailyWeatherArray.length(); i++)
            {
                JSONObject dailyTraverse = (JSONObject) dailyWeatherArray.get(i);
                JSONObject dailyTraverseTemps = dailyTraverse.getJSONObject("temp");
                JSONArray dailyTraverseWeather = dailyTraverse.getJSONArray("weather");
                JSONObject dailyTraverseWeatherInstance = (JSONObject) dailyTraverseWeather.get(0);
                String traverseMorning = dailyTraverseTemps.getString("morn");
                String traverseAfternoon = dailyTraverseTemps.getString("day");
                String traverseEvening = dailyTraverseTemps.getString("eve");
                String traverseNight = dailyTraverseTemps.getString("night");
                String traverseHigh = dailyTraverseTemps.getString("max");
                String traverseLow = dailyTraverseTemps.getString("min");
                String traverseDescription = dailyTraverseWeatherInstance.getString("description");
                String traverseIcon = dailyTraverseWeatherInstance.getString("icon");
                String traverseUV = dailyTraverse.getString("uvi");
                String traversePercip = dailyTraverse.getString("pop");
                String traverseDt = dailyTraverse.getString("dt");
                dailyList.add(new DailyWeather(traverseHigh, traverseLow, traverseDescription, traversePercip, traverseUV,
                        traverseIcon, traverseMorning, traverseAfternoon, traverseEvening, traverseNight, traverseDt,
                        timezoneOffset));
            }
            dailyAct.updateData(dailyList);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
