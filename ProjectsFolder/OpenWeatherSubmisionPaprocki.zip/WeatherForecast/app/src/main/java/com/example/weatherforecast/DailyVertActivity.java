package com.example.weatherforecast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DailyVertActivity extends AppCompatActivity {
    //Fields for the daily forecast activity
    private RecyclerView recyclerView;
    private final ArrayList<DailyWeather> dailyWeatherList = new ArrayList<>();
    DailyAdapter dailyAdapter;
    private LinearLayoutManager linearLayoutManager;
    private String location;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_vert);

        //Creates the recycler view for the daily forecast
        recyclerView = findViewById(R.id.dailyVertRecycler);
        dailyAdapter = new DailyAdapter(this, dailyWeatherList);
        recyclerView.setAdapter(dailyAdapter);
        linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        //Gets the location from the main activity
        Intent fromMain = getIntent();
        if(fromMain.hasExtra("LOCATION"))
        {
            location = fromMain.getStringExtra("LOCATION");

            if(location != null)
            {
                newData();
                try {
                    getSupportActionBar().setTitle(getLocationName(getLatLon(location)));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            else
            {
                Toast.makeText(this, "Please add a location.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    //Gets the new data from the API
    private void newData() {
        double lat = getLatLon(location)[0];
        double lon = getLatLon(location)[1];
        DailyDownloader.downloadInfo(this, lat, lon, true);
    }

    //Updates the information displayed in the daily forecast
    public void updateData(ArrayList<DailyWeather> d) {
        dailyWeatherList.clear();
        dailyWeatherList.addAll(d);
        dailyAdapter.notifyDataSetChanged();
    }

    //Gets the coordinates from a location name
    public double[] getLatLon(String userProvidedLocation) {
        Geocoder geocoder = new Geocoder(this);
        try {
            List<Address> address =
                    geocoder.getFromLocationName(userProvidedLocation, 1);
            if (address == null || address.isEmpty()) {
                return null;
            }
            double lat = address.get(0).getLatitude();
            double lon = address.get(0).getLongitude();

            return new double[] {lat, lon};
        } catch (IOException e) {
            // Failure to get an Address object
            return null;
        }
    }
    //Uses coordinate to make a location name
    private String getLocationName(double[] latLon) throws IOException {
        String locationName = "No Location Selected";
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses;
            addresses = geocoder.getFromLocation(latLon[0], latLon[1], 1);
            Address local = addresses.get(0);
            locationName = local.getLocality() + ", " + local.getAdminArea() + ", " + local.getCountryName();
        }catch (IOException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
        return locationName;
    }

    //When the back button is pressed the user is taken back to the main activity
    @Override
    public void onBackPressed() {
        Intent backToMain = new Intent(this, MainActivity.class);
        startActivity(backToMain);
        super.onBackPressed();
    }
}