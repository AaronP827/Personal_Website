package com.example.weatherforecast;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

public class HourlyAdapter extends RecyclerView.Adapter<HourlyViewHolder> {

    private final ArrayList<HourlyWeather> hourlyThumbnailList;
    private final MainActivity mainAct;

    public HourlyAdapter(MainActivity mainAct, ArrayList<HourlyWeather> hourlyThumbnailList)
    {
        this.mainAct = mainAct;
        this.hourlyThumbnailList = hourlyThumbnailList;
    }

    @NonNull
    @Override
    public HourlyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.hourly_thumbnail, parent, false);
        return new HourlyViewHolder(itemView);
    }

    //Populates the hourly recycler view with data from the API call
    @Override
    public void onBindViewHolder(@NonNull HourlyViewHolder holder, int position)
    {
        String units;
        if(mainAct.imperial)
        {
            units = "F";
        }
        else
        {
            units = "C";
        }

        HourlyWeather h = hourlyThumbnailList.get(position);
        LocalDateTime ldt =
                LocalDateTime.ofEpochSecond(calcEpoch(h.getDt(), h.getTimezone()), 0, ZoneOffset.UTC);
        DateTimeFormatter day =
                DateTimeFormatter.ofPattern("EEEE", Locale.getDefault());
        String currentDate = day.format(MainActivity.now);
        DateTimeFormatter time = DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault());
        String formattedTime = ldt.format(time);
        String formattedDay = ldt.format(day);
        if(formattedDay.equals(currentDate))
        {
            holder.day.setText("Today");
        }
        else
        {
            holder.day.setText(formattedDay);
        }
        holder.clouds.setText(mainAct.toCapitalize(h.getDescription()));
        holder.temp.setText(mainAct.toTemp(h.getTemperature()) + "°" + units);
        holder.time.setText(formattedTime);
        int iconID = mainAct.getResources().getIdentifier(("_" + h.getIcon()), "drawable", mainAct.getPackageName());
        holder.image.setImageResource(iconID);
    }
    private Long calcEpoch(String dt, String timeZone)
    {
        return Long.parseLong(dt) + Long.parseLong(timeZone);
    }

    @Override
    public int getItemCount() {
        return hourlyThumbnailList.size();
    }
}