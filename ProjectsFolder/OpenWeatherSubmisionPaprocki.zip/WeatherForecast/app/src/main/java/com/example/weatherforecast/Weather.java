package com.example.weatherforecast;

public class Weather
{
    //Fields for Weather
    private String sunrise;
    private String sunset;
    private String temperature;
    private String feelsLike;
    private String humidity;
    private String uvIndex;
    private String visibility;
    private String winds;
    private String description;
    private String morningTemp;
    private String afternoonTemp;
    private String eveningTemp;
    private String nightTemp;
    private String timeOffset;
    private String dt;
    private String icon;

    //Constructor for Weather
    public Weather(String sunset, String sunrise, String temperature, String feelsLike,
                   String humidity, String uvIndex, String visibility, String winds,
                   String description, String morningTemp, String afternoonTemp,
                   String eveningTemp, String nightTemp, String timeOffset, String dt, String icon)
    {
        this.temperature = temperature;
        this.description = description;
        this.sunrise = sunrise;
        this.sunset = sunset;
        this.feelsLike = feelsLike;
        this.humidity = humidity;
        this.uvIndex = uvIndex;
        this.visibility = visibility;
        this.winds = winds;
        this.morningTemp = morningTemp;
        this.afternoonTemp = afternoonTemp;
        this.eveningTemp = eveningTemp;
        this.nightTemp = nightTemp;
        this.timeOffset = timeOffset;
        this.dt = dt;
        this.icon = icon;
    }

    //Getters for Weather
    public String getSunrise() {
        return sunrise;
    }

    public String getSunset() {
        return sunset;
    }

    public String getTemperature() {
        return temperature;
    }

    public String getFeelsLike() {
        return feelsLike;
    }

    public String getHumidity() {
        return humidity;
    }

    public String getUvIndex() {
        return uvIndex;
    }

    public String getVisibility() {
        return visibility;
    }

    public String getWinds() {
        return winds;
    }

    public String getDescription() {
        return description;
    }

    public String getMorningTemp() {
        return morningTemp;
    }

    public String getAfternoonTemp() {
        return afternoonTemp;
    }

    public String getEveningTemp() {
        return eveningTemp;
    }

    public String getNightTemp() {
        return nightTemp;
    }

    public String getTimeOffset() {
        return timeOffset;
    }

    public String getDt() {
        return dt;
    }

    public String getIcon() {
        return icon;
    }

}
