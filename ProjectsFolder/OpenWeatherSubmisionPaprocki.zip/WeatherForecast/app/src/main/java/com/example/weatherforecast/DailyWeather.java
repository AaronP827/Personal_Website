package com.example.weatherforecast;

import java.io.Serializable;

public class DailyWeather implements Serializable {
    //Fields for the daily weather
    private String highTemp;
    private String dt;
    private String lowTemp;
    private String description;
    private String percip;
    private String UV;
    private String icon;
    private String morningTemp;
    private String afternoonTemp;
    private String eveningTemp;
    private String nightTemp;
    private String timezone;

    //Constructor for daily weather
    public DailyWeather(String ht, String lt, String description, String percip, String uv, String icon,
                        String mt, String at, String et, String nt, String dt, String tz)
    {
        highTemp = ht;
        lowTemp = lt;
        this.description = description;
        this.percip = percip;
        this.UV = uv;
        this.icon = icon;
        morningTemp = mt;
        afternoonTemp = at;
        eveningTemp = et;
        nightTemp = nt;
        this.dt = dt;
        timezone = tz;
    }

    //Getters for the daily weather
    public String getHighTemp() {
        return highTemp;
    }

    public String getDt() {
        return dt;
    }

    public String getLowTemp() {
        return lowTemp;
    }

    public String getDescription() {
        return description;
    }

    public String getPercip() {
        return percip;
    }

    public String getUV() {
        return UV;
    }

    public String getIcon() {
        return icon;
    }

    public String getMorningTemp() {
        return morningTemp;
    }

    public String getAfternoonTemp() {
        return afternoonTemp;
    }

    public String getEveningTemp() {
        return eveningTemp;
    }

    public String getNightTemp() {
        return nightTemp;
    }

    public String getTimezone() {
        return timezone;
    }
}
