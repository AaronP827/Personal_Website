package com.example.weatherforecast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity{
    //Field variables
    public static boolean imperial = true;
    public static LocalDateTime now = LocalDateTime.now();
    private String location = "Chicago";
    private Menu menuOptions;
    private boolean connected = false;

    private final String TAG = getClass().getSimpleName();
    private RecyclerView recyclerView;
    private final ArrayList<HourlyWeather> hourlyWeatherList = new ArrayList<>();
    HourlyAdapter hourlyAdapter;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Sets up the recycler view for the hourly weather in the main method
        recyclerView = findViewById(R.id.hourlyHorizontalRecycler);
        hourlyAdapter = new HourlyAdapter(this, hourlyWeatherList);
        recyclerView.setAdapter(hourlyAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this,
                LinearLayoutManager.HORIZONTAL, false));

        //Handles the condition if there is no network connection
        connected = hasNetworkConnection();
        if(!connected)
        {
            TextView noConnection = findViewById(R.id.timeDisplay);
            TextView eightAM = findViewById(R.id.eightAM);
            TextView onePM = findViewById(R.id.onePM);
            TextView fivePM = findViewById(R.id.fivePM);
            TextView elevenPM = findViewById(R.id.elevenPM);
            ImageView mainImage = findViewById(R.id.mainImage);
            noConnection.setText("No Internet Connection");
            eightAM.setText("");
            onePM.setText("");
            fivePM.setText("");
            elevenPM.setText("");
            mainImage.setVisibility(View.INVISIBLE);
        }
        //Calls the method to get new data
        newData();
    }

    private void newData() {
        if(connected) {
            double lat = getLatLon(location)[0];
            double lon = getLatLon(location)[1];
            ContentDownloader.downloadInfo(this, lat, lon, imperial);
        }
    }

    //Inflates the menu bar to show all the options
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        menuOptions = menu;
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        //User selects the toggle units button
        if(item.getItemId() == R.id.toggleUnitsButton)
        {
            if (connected)
            {
                Log.d(TAG, "onOptionsItemSelected: Toggle units button has been selected");
                imperial = !imperial;
                if (imperial) {
                    menuOptions.getItem(2).setIcon(ContextCompat.getDrawable(this, R.drawable.units_f));
                } else {
                    menuOptions.getItem(2).setIcon(ContextCompat.getDrawable(this, R.drawable.units_c));
                }
                newData();
            }
            else{
                Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show();
            }
        }
        //User selects the daily forecast
        else if(item.getItemId() == R.id.dailyForecastButton)
        {
            if(connected)
            {
                Log.d(TAG, "onOptionsItemSelected: Daily forecast button has been selected");
                Intent daily = new Intent(this, DailyVertActivity.class);
                daily.putExtra("LOCATION", location);
                startActivity(daily);
            }
            else{
                Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show();
            }
        }
        //The user selects the change location button
        else if(item.getItemId()==R.id.changeLocationButton) {
            if (connected) {
                Log.d(TAG, "onOptionsItemSelected: Change location button has been selected");
                AlertDialog.Builder newLocation = new AlertDialog.Builder(this);

                final EditText et = new EditText(this);
                et.setInputType(InputType.TYPE_CLASS_TEXT);
                et.setGravity(Gravity.CENTER_HORIZONTAL);
                newLocation.setView(et);

                newLocation.setIcon(R.drawable.location);

                newLocation.setPositiveButton("SET NEW LOCATION", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        location = (et.getText()).toString();
                        newData();
                    }
                });
                newLocation.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        Toast.makeText(MainActivity.this, "No new location selected", Toast.LENGTH_SHORT).show();
                    }
                });

                newLocation.setMessage("Please enter the city you would like to see the weather for:");
                newLocation.setTitle("Selecting a New Location");

                AlertDialog dialog = newLocation.create();
                dialog.show();
            }
            else{
                Toast.makeText(this,"No internet connection", Toast.LENGTH_LONG).show();
            }
        }
        else
        {
            Log.d(TAG, "onOptionsItemSelected: Unknown menu option has been selected");
        }
        return super.onOptionsItemSelected(item);
    }

    //Updates the data displayed to the user
    @SuppressLint("SetTextI18n")
    public void updateData(Weather w) throws IOException {
        //Sees what preferences the user has to set up the units display
        String units;
        String speed;
        DecimalFormat df = new DecimalFormat("0.0");
        if(imperial)
        {
            units = "F";
            speed = "mph";
        }
        else
        {
            units = "C";
            speed = "m/s";
        }

        TextView currentLocation = findViewById(R.id.locationDisplay);
        currentLocation.setText(getLocationName(getLatLon(location)));

        //Creates tools to display the current time
        TextView currentTime = findViewById(R.id.timeDisplay);
        LocalDateTime ldt =
                LocalDateTime.ofEpochSecond(calcEpoch(w.getDt(), w.getTimeOffset()), 0, ZoneOffset.UTC);
        DateTimeFormatter dtf =
                DateTimeFormatter.ofPattern("EEE MMM dd h:mm a, yyyy", Locale.getDefault());
        String formattedTimeString = ldt.format(dtf);
        currentTime.setText(formattedTimeString);

        //Sets the temperatures
        TextView currentTemp = findViewById(R.id.temperatureDisplay);
        String finalCurrentTemp = toTemp(w.getTemperature()) + "°" + units;
        currentTemp.setText(finalCurrentTemp);

        TextView feelsLike = findViewById(R.id.feelsLikeDisplay);
        String finalFeelsLikeTemp = ("Feels Like " + toTemp(w.getFeelsLike()) + "°" + units);
        feelsLike.setText(finalFeelsLikeTemp);

        TextView percentClouds = findViewById(R.id.cloudsDisplay);
        percentClouds.setText(toCapitalize(w.getDescription()));

        TextView winds = findViewById(R.id.windSpeedDisplay);
        String finalWinds = "Winds: " + w.getWinds() + speed;
        winds.setText(finalWinds);

        TextView humidity = findViewById(R.id.humidityDisplay);
        String finalHumidity = "Humidity: " + w.getHumidity() + "%";
        humidity.setText(finalHumidity);

        TextView UV = findViewById(R.id.uvIndexDisplay);
        String finalUVIndex = "UV Index: " + w.getUvIndex();
        UV.setText(finalUVIndex);

        TextView visibility = findViewById(R.id.visibilityDisplay);
        double visibilityDub = Double.parseDouble(w.getVisibility());
        visibilityDub *= 0.001;
        if(imperial)
        {
            visibilityDub *= 0.621371;
            visibility.setText("Visibility " + df.format(visibilityDub) + " mi");
        }
        else
        {
            visibility.setText("Visibility " + df.format(visibilityDub) + " km");
        }

        TextView sunrise = findViewById(R.id.sunriseTime);
        LocalDateTime ldtSunrise =
                LocalDateTime.ofEpochSecond(calcEpoch(w.getSunrise(), w.getTimeOffset()), 0, ZoneOffset.UTC);
        DateTimeFormatter sunriseOrSunset =
                DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault());
        String formattedSunrise = ldtSunrise.format(sunriseOrSunset);
        sunrise.setText("Sunrise: " + formattedSunrise);

        TextView sunset = findViewById(R.id.sunsetTime);
        LocalDateTime ldtSunset =
                LocalDateTime.ofEpochSecond(calcEpoch(w.getSunset(), w.getTimeOffset()), 0, ZoneOffset.UTC);
        String formattedSunset = ldtSunset.format(sunriseOrSunset);
        sunset.setText("Sunset: " + formattedSunset);

        TextView morningTemp = findViewById(R.id.morningTempDisplay);
        String finalMorningTemp = toTemp(w.getMorningTemp()) +  "°" + units;
        morningTemp.setText(finalMorningTemp);

        TextView afternoonTemp = findViewById(R.id.afternoonTempDisplay);
        String finalAfternoonTemp = toTemp(w.getAfternoonTemp()) +  "°" + units;
        afternoonTemp.setText(finalAfternoonTemp);

        TextView eveningTemp = findViewById(R.id.eveningTempDisplay);
        String finalEveningTemp = toTemp(w.getEveningTemp()) +  "°" + units;
        eveningTemp.setText(finalEveningTemp);

        TextView nightTemp = findViewById(R.id.nightTempDisplay);
        String finalNightTemp = toTemp(w.getNightTemp()) +  "°" + units;
        nightTemp.setText(finalNightTemp);

        ImageView image = findViewById(R.id.mainImage);
        String iconCode = "_" + w.getIcon();
        int iconID = this.getResources().getIdentifier(iconCode, "drawable", this.getPackageName());
        image.setImageResource(iconID);
    }
    public static String toTemp(String s)
    {
        double tempDub = Double.parseDouble(s);
        int tempInt = Math.toIntExact(Math.round(tempDub));
        return Integer.toString(tempInt);
    }
    private Long calcEpoch(String dt, String timeZone)
    {
        return Long.parseLong(dt) + Long.parseLong(timeZone);
    }

    //Updates the hourly recycler view
    public void updateHourly(ArrayList<HourlyWeather> h)
    {
        hourlyWeatherList.clear();
        hourlyWeatherList.addAll(h);
        hourlyAdapter.notifyDataSetChanged();
    }
    //Capitalizes the first letter of each word in a string
    public static String toCapitalize(String s)
    {
        char[] charList = s.toCharArray();
        boolean foundSpace = true;
        for(int i = 0; i < charList.length; i++)
        {
            if(Character.isLetter(charList[i])){
                if(foundSpace){
                    charList[i] = Character.toUpperCase(charList[i]);
                    foundSpace = false;
                }
            }
            else{
                foundSpace = true;
            }
        }
        return String.valueOf(charList);
    }

    //Takes a string and returns the lat and lon coordinates of a location
    public double[] getLatLon(String userProvidedLocation) {
        Geocoder geocoder = new Geocoder(this);
        try {
            List<Address> address =
                    geocoder.getFromLocationName(userProvidedLocation, 1);
            if (address == null || address.isEmpty()) {
                return null;
            }
            double lat = address.get(0).getLatitude();
            double lon = address.get(0).getLongitude();

            return new double[] {lat, lon};
        } catch (IOException e) {
            // Failure to get an Address object
            return null;
        }
    }

    //Takes an array of lat lon coordinates to return a string with the name of the location
    private String getLocationName(double[] latLon) throws IOException {
        String locationName = "No Location Selected";
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses;
            addresses = geocoder.getFromLocation(latLon[0], latLon[1], 1);
            Address local = addresses.get(0);
            locationName = local.getLocality() + ", " + local.getAdminArea() + ", " + local.getCountryName();
        }catch (IOException e) {
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
        return locationName;
    }

    //Verifies if there is a network connection or not
    private boolean hasNetworkConnection() {
        ConnectivityManager connectivityManager = getSystemService(ConnectivityManager.class);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        return (networkInfo != null && networkInfo.isConnectedOrConnecting());
    }
}