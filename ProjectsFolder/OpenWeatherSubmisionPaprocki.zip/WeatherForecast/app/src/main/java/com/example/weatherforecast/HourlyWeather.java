package com.example.weatherforecast;

import java.io.Serializable;

public class HourlyWeather implements Serializable
{
    //Fields for the hourly weather
    private String dt;
    private String temperature;
    private String description;
    private String icon;
    private String timezone;

    //Constructor for hourly weather
    public HourlyWeather(String dt, String temperature, String d, String i, String t)
    {
        this.dt = dt;
        this.temperature = temperature;
        description = d;
        icon = i;
        timezone = t;
    }

    //Getter for hourly weather
    public String getDt() {
        return dt;
    }

    public String getDescription() {
        return description;
    }

    public String getTemperature() {
        return temperature;
    }

    public String getIcon() {
        return icon;
    }

    public String getTimezone() {
        return timezone;
    }
}