package com.example.weatherforecast;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Locale;

public class DailyAdapter extends RecyclerView.Adapter<DailyViewHolder> {

    private final ArrayList<DailyWeather> dailyThumbnailList;
    private final DailyVertActivity dailyVertActivity;

    public DailyAdapter(DailyVertActivity dailyVertActivity, ArrayList<DailyWeather> dailyThumbnailList)
    {
        this.dailyVertActivity = dailyVertActivity;
        this.dailyThumbnailList = dailyThumbnailList;
    }

    @NonNull
    @Override
    public DailyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.daily_vert_thumbnail, parent, false);
        return new DailyViewHolder(itemView);
    }

    //Populates the recycler view with the information gotten from the API
    @Override
    public void onBindViewHolder(@NonNull DailyViewHolder holder, int position)
    {
        String units;
        if(MainActivity.imperial)
        {
            units = "F";
        }
        else
        {
            units = "C";
        }

        DailyWeather d = dailyThumbnailList.get(position);
        LocalDateTime ldt =
                LocalDateTime.ofEpochSecond(calcEpoch(d.getDt(), d.getTimezone()), 0, ZoneOffset.UTC);
        DateTimeFormatter date =
                DateTimeFormatter.ofPattern("EEEE, M/d", Locale.getDefault());
        String formattedDate = ldt.format(date);
        holder.date.setText(formattedDate);
        holder.description.setText(MainActivity.toCapitalize(d.getDescription()));
        holder.highLow.setText(MainActivity.toTemp(d.getHighTemp()) + "°" + units + "/" + MainActivity.toTemp(d.getLowTemp()) + "°" + units);
        double percentPercip = Double.parseDouble(d.getPercip()) * 100;
        int intPercip = Math.toIntExact(Math.round(percentPercip));
        holder.percip.setText(intPercip + "% precipitation");
        int iconID = dailyVertActivity.getResources().getIdentifier(("_" + d.getIcon()), "drawable", dailyVertActivity.getPackageName());
        holder.image.setImageResource(iconID);
        holder.uv.setText("UV Index: " + d.getUV());
        holder.morningTemp.setText(MainActivity.toTemp(d.getMorningTemp())+ "°" + units);
        holder.afternoonTemp.setText(MainActivity.toTemp(d.getAfternoonTemp())+ "°" + units);
        holder.eveningTemp.setText(MainActivity.toTemp(d.getEveningTemp())+ "°" + units);
        holder.nightTemp.setText(MainActivity.toTemp(d.getNightTemp())+ "°" + units);
    }
    private Long calcEpoch(String dt, String timeZone)
    {
        return Long.parseLong(dt) + Long.parseLong(timeZone);
    }

    @Override
    public int getItemCount() {
        return dailyThumbnailList.size();
    }
}
