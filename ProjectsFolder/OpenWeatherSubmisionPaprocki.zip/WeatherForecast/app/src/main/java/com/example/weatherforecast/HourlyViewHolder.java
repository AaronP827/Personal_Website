package com.example.weatherforecast;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class HourlyViewHolder extends RecyclerView.ViewHolder {
    TextView day;
    TextView time;
    TextView temp;
    TextView clouds;
    ImageView image;

    public HourlyViewHolder(@NonNull View itemView) {
        super(itemView);
        day = itemView.findViewById(R.id.todayThumb);
        time = itemView.findViewById(R.id.dailyTimeThumb);
        temp = itemView.findViewById(R.id.dailyTempThumb);
        clouds = itemView.findViewById(R.id.cloudsThumb);
        image = itemView.findViewById(R.id.thumbPic);
    }
}